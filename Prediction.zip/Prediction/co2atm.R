
setwd("C:/Users/Ana/Documents/Programa��o R/Nova pasta")
data <- read.csv("meanco2.csv")
library(readr)
library(ggplot2)
library(fpp2)
library(fpp)
library(TTR)
library(dplyr)
library(readxl)

#Time series
ts_co2 <- ts(data$co, start = c(2011,1),frequency = 12)
plot(ts_co2)
ts_co2
forecast::autoplot(ts_co2)

#Spliting the data into train and test
treinamento = window(ts_co2, end=2018)
teste = window(ts_co2, start= 2019)

#Fitting our data to arima method
fit_arima <- auto.arima(ts_co2,d=1,D=1,stepwise = FALSE, approximation = FALSE, trace = TRUE)
print(summary(fit_arina))
checkresiduals(fit_arina)

#Forecast object
fcst <- forecast( fit_arima, h = 24 )
autoplot(fcst, include = 70, xlab = "Year", ylab = "CO2 (ppm)",main = "CO2 Forecast")
previsao <- fcst$mean
summary(fcst)

accuracy(previsao, teste)

#---
library(tidyquant)
install.packages("plotly")
library(plotly)

fig <- data %>%
  plot_ly(x= ~data$ano,y= ~co)

fig

