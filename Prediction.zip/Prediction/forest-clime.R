library(readr)
library(ggplot2)
library(fpp2)
library(fpp)
library(TTR)
library(dplyr)
library(readxl)


mydata <- read_excel("~/NASA/DADOS/aaaaaa/DADOS.MES.TEMP.xlsx", 
                                      sheet = "Planilha2")
#declare as time series data

Temperatura <- ts( mydata[,3] , start = c(1981,1) ,frequency = 12 )

#ANALISE PRELIMINAR

autoplot(Temperatura) + ggtitle("Temperatura por ano em Sao Paulo")

#Nao temos trend, precisamos tirar a sazonalidade seazons plot:

ggseasonplot(Temperatura) 

ggsubseriesplot(Temperatura)

#Benchmark method

fit <- snaive(Temperatura) #Residual sd: 3.2153 
print(summary(fit))
checkresiduals(fit)

#Find a better model 
#Fit on ETS = SD 0.1246

fit_etc <- ets(Temperatura)
print(summary(fit_etc))
checkresiduals(fit_etc)

#Fit on Arina model SD =2.673574 

fit_arina <- auto.arima(Temperatura,d=1,D=1,stepwise = FALSE, approximation = FALSE, trace = TRUE)
print(summary(fit_arina))
checkresiduals(fit_arina)

#Forecast

fcst <- forecast( fit_etc, h = 24 )
autoplot(fcst, include = 180)
fcst




